# VisualizandoShapefile
Aplicativo para visualização do shapefile  importado na plataforma ARCGIS Develop. Trabalho desenvolvido na disciplina de Sistemas de Informação Geografica na Web do curso de pós graduação de desenvolvimento web e mobile
