# MOB05008
MOB05008 - SISTEMAS DE INFORMAÇÕES GEOGRÁFICAS NA WEB - T20220201 (2023.1)


Sistema em java que exibe seu posicionamento global, desenvolvido na disciplina Sistemas de Informação Geografica na Web do curso de desenvolvimento web e mobile


<img width="934" alt="image" src="https://github.com/jonathasborges1/MOB05008/assets/12356493/ac7faec9-cda1-4146-883b-c67f273a6a02">
